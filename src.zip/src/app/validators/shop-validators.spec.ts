import { ShopValidators } from './shop-validators';

describe('ShopValidators', () => {
  it('should create an instance', () => {
    expect(new ShopValidators()).toBeTruthy();
  });
});
