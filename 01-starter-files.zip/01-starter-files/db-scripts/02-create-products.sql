-- -----------------------------------------------------
-- Schema full-stack-ecommerce
-- -----------------------------------------------------
DROP SCHEMA IF EXISTS `full-stack-ecommerce`;

CREATE SCHEMA `full-stack-ecommerce`;
USE `full-stack-ecommerce` ;

-- -----------------------------------------------------
-- Table `full-stack-ecommerce`.`product_category`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `full-stack-ecommerce`.`product_category` (
  `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `category_name` VARCHAR(255) NULL DEFAULT NULL,
  PRIMARY KEY (`id`))
ENGINE=InnoDB
AUTO_INCREMENT = 1;

-- -----------------------------------------------------
-- Table `full-stack-ecommerce`.`product`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `full-stack-ecommerce`.`product` (
  `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `sku` VARCHAR(255) DEFAULT NULL,
  `name` VARCHAR(255) DEFAULT NULL,
  `description` VARCHAR(255) DEFAULT NULL,
  `unit_price` DECIMAL(13,2) DEFAULT NULL,
  `image_url` VARCHAR(255) DEFAULT NULL,
  `active` BIT DEFAULT 1,
  `units_in_stock` INT(11) DEFAULT NULL,
   `date_created` DATETIME(6) DEFAULT NULL,
  `last_updated` DATETIME(6) DEFAULT NULL,
  `category_id` BIGINT(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_category` (`category_id`),
  CONSTRAINT `fk_category` FOREIGN KEY (`category_id`) REFERENCES `product_category` (`id`)
) 
ENGINE=InnoDB
AUTO_INCREMENT = 1;


-- -----------------------------------------------------
-- Add sample data
-- -----------------------------------------------------

INSERT INTO product_category(category_name) VALUES ('SPORTS');
INSERT INTO product_category(category_name) VALUES ('FITNESS');


INSERT INTO product (sku, name, description, image_url, active, units_in_stock,
unit_price, category_id, date_created)
VALUES ('SPORTS-GOODS-1000', 'Champion Carrom Board', 'Matt / Dull finish , 100% waterproof carrom board for tournament. Available in Black frames/Borders',
'assets/images/products/Sports/Champion - Carrom.jpeg'
,1,100,3350,1, NOW());

INSERT INTO product (sku, name, description, image_url, active, units_in_stock,
unit_price, category_id, date_created)
VALUES ('SPORTS-GOODS-1001', 'Badminton', 'Aluminium and steel blended material. It is light in weight around 90 to 95 gram and can be used to swing with great accuracy and control  ',
'assets/images/products/Sports/Badminton.jpg'
,1,100,715,1, NOW());

INSERT INTO product (sku, name, description, image_url, active, units_in_stock,
unit_price, category_id, date_created)
VALUES ('SPORTS-GOODS-1002', 'Supreme Carrom Board', 'Matt/Dull finish , 100% water proof , elegant carrom board for high class tournaments. The board available in natural finish frames fitted with Sheesham wood.',
'assets/images/products/Sports/Supreme - Carrom.jpeg'
,1,100,4140,1, NOW());

INSERT INTO product (sku, name, description, image_url, active, units_in_stock,
unit_price, category_id, date_created)
VALUES('SPORTS-GOODS-1003', 'Tennis Set', 'Racket - Lightweight, strong impact resistance. Good shock absorption effect, bring better hitting feeling....
Tennis ball - Great bounce and grip',
'assets/images/products/Sports/Tennis.jpg'
,1,100,1250,1, NOW());

INSERT INTO product (sku, name, description, image_url, active, units_in_stock,
unit_price, category_id, date_created)
VALUES('SPORTS-GOODS-1004', 'Football', 'Reach for this Adidas training ball when you want to sharpen your skills or kick around at park. Football has PPU cover and machine stitched construction for durability',
'assets/images/products/Sports/football.jpg'
,1,100,1799,1, NOW());

INSERT INTO product (sku, name, description, image_url, active, units_in_stock,
unit_price, category_id, date_created)
VALUES ('SPORTS-GOODS-1005','Kashmir Willow Cricket Bat', 'Duco Painted Cricket Bats fitted with one piece wooden handle and recommended to play with tennis ball',
'assets/images/products/Sports/The - Kids - Bat.png'
,1,100,1500,1, NOW());

INSERT INTO product (sku, name, description, image_url, active, units_in_stock,
unit_price, category_id, date_created)
VALUES ('SPORTS-GOODS-1006', 'Carrom Stand', 'Hydraulic adjustable carrom board stand. ',
'assets/images/products/Sports/Carrom-Stand.jpeg'
,1,100,1100,1, NOW());

INSERT INTO product (sku, name, description, image_url, active, units_in_stock,
unit_price, category_id, date_created)
VALUES ('SPORTS-GOODS-1007', 'Carrom Coin', 'Carrom coins set (24 coins) with 1 qty striker, Package contains 11 wooden color coins, 2 red (queen) color coins, 11 black color coins,1 qty striker , 1 plastic carry box. SUMO carrom coins, 10 mm thickness',
'assets/images/products/Sports/coin.jpeg'
,1,100,199,1, NOW());

INSERT INTO product (sku, name, description, image_url, active, units_in_stock,
unit_price, category_id, date_created)
VALUES('SPORTS-GOODS-1008', 'Legend Carrom Board', 'Birch ply (English Ply) water proof carrom board with extra rebounce for tournaments',
'assets/images/products/Sports/The Legend.jpeg'
,1,100,2750,1, NOW());

INSERT INTO product (sku, name, description, image_url, active, units_in_stock,
unit_price, category_id, date_created)
VALUES ('SPORTS-GOODS-1009', 'Patriot Cricket Bat', 'Popular willow tennis ball play Cricket Bats available in Tetron/ Full Cotton Cover fitted with Full Cane / four part wooden handle',
'assets/images/products/Sports/The - Patriot - Bat.png'
,1,100,650,1, NOW());


INSERT INTO product (sku, name, description, image_url, active, units_in_stock,
unit_price, category_id, date_created)
VALUES ('GYM-EQUIPMENTS-1010', 'Dumbell Set', 'A combination of gym equipment for the perfect workout. Highly durable and long lasting. A perfect muscle builder ',
'assets/images/products/Fitness/dumbell.jpg'
,1,100,3000,2, NOW());

INSERT INTO product (sku, name, description, image_url, active, units_in_stock,
unit_price, category_id, date_created)
VALUES ('GYM-EQUIPMENTS-1011', 'Benchpress', 'High grade steel frame with resistance tubes that come with the machine are made of pure latex, and the foot pads are made of soft foam. The durable skeleton makes the bench press machine remain stable and carry workout load up to 125Kg.',
'assets/images/products/Fitness/benchpress.jpg'
,1,100,10000,2, NOW());

INSERT INTO product (sku, name, description, image_url, active, units_in_stock,
unit_price, category_id, date_created)
VALUES ('GYM-EQUIPMENTS-1012', 'Treadmill', 'Motor Horsepower: 3.25HP || Motor Type: DC-Motorized || Belt size: 1240x420 Milimeter || Speed: 0.8-14.8 kilometer per hour || Max Weight support: 110 Kilogram || Lubrication: Manual',
'assets/images/products/Fitness/treadmill.jpg'
,1,100,12000,2, NOW());

INSERT INTO product (sku, name, description, image_url, active, units_in_stock,
unit_price, category_id, date_created)
VALUES ('GYM-EQUIPMENTS-1013', 'Punching Bag', 'Material: High quality PU used
Extreme durability - Bag is double stitched, reinforced with heavy duty d-shackles
Comfortable - Filled with recycled materials which is not too hard on your hands',
'assets/images/products/Fitness/punching-bag.jpg'
,1,100,3000,2, NOW());

INSERT INTO product (sku, name, description, image_url, active, units_in_stock,
unit_price, category_id, date_created)
VALUES ('GYM-EQUIPMENTS-1014', 'Yoga Mat', 'Our yoga mat is made of technically improved TPE (thermoplastic elastomer) material. It is a flexible material that can be stretched repeatedly to provide excellent durability, abrasion resistance and no harmful chemicals.',
'assets/images/products/Fitness/yogamat.jpg'
,1,100,700,2, NOW());

INSERT INTO product (sku, name, description, image_url, active, units_in_stock,
unit_price, category_id, date_created)
VALUES ('GYM-EQUIPMENTS-1015', 'Chestpress ', 'Tilt Design In Our Push Up Bar For Men And Women Which Will Reduce Pressure From Your Wrist So You Can Do More Counts Of Push Ups At One Time. With This Single Equipment You Can Exercise Multiple Parts Of Your Body',
'assets/images/products/Fitness/chestpress.jpg'
,1,100,13000,2, NOW());

INSERT INTO product (sku, name, description, image_url, active, units_in_stock,
unit_price, category_id, date_created)
VALUES ('GYM-EQUIPMENTS-1016', 'Kettlebell Set', 'Kettle Bell for Strength Cardio Training and for Home and Gym Fitness Workout for Bodybuilding Weight Lifting',
'assets/images/products/Fitness/kettlebell.jpg'
,1,100,1600,2, NOW());


INSERT INTO product (sku, name, description, image_url, active, units_in_stock,
unit_price, category_id, date_created)
VALUES ('GYM-EQUIPMENTS-1017', 'Barbel', 'Aurion 6 FEET , 26 MM solid weight bar is compact and convenient enough for all gyms and homes. The lifting bar features a solid chromed steel bar',
'assets/images/products/Fitness/barbel.jpg'
,1,100,750,2, NOW());

INSERT INTO product (sku, name, description, image_url, active, units_in_stock,
unit_price, category_id, date_created)
VALUES ('GYM-EQUIPMENTS-1018', 'Bicycle', 'Wool Felt Resistance, Quick Breaking System, 18 Kg Fly Wheel, 8 Level of Magnetic Resistance, CageShape Pedals with adjustable Strap, Easy to move Wheels, 4 Way adjustable Seat, Handle Height Adjustment, Bottle Holder, Ergonomic Seat',
'assets/images/products/Fitness/Bicyle.jpg'
,1,100,13000,2, NOW());

INSERT INTO product (sku, name, description, image_url, active, units_in_stock,
unit_price, category_id, date_created)
VALUES ('GYM-EQUIPMENTS-1019', 'Rowing Machine', 'Rowing Machine with heavy duty steel frame for high intensity cardio training; ideal for working out both upper, lower body as well as abs region',
'assets/images/products/Fitness/rowingmachine.jpg'
,1,100,15000,2, NOW());












